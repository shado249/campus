package com.campus.app

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.School
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun AppLogo(size: Dp = 92.dp) {
    Box(Modifier.size(size)) {
        Box(
            Modifier.fillMaxSize().clip(RoundedCornerShape(size * 0.28f)).background(Blue),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Filled.School, null, tint = Color.White, modifier = Modifier.size(size * 0.55f))
        }
        Box(
            Modifier.align(Alignment.BottomEnd).offset(6.dp, 6.dp).size(26.dp)
                .clip(CircleShape).background(Yellow).border(4.dp, Color.White, CircleShape)
        )
    }
}

/** Blue rounded header with the yellow accent bar, used on every screen. */
@Composable
fun ScreenHeader(title: String, subtitle: String) {
    Box(Modifier.fillMaxWidth()) {
        Column(
            Modifier.fillMaxWidth()
                .clip(RoundedCornerShape(bottomStart = 34.dp, bottomEnd = 34.dp))
                .background(Blue)
                .padding(start = 24.dp, end = 24.dp, top = 28.dp, bottom = 40.dp)
        ) {
            Box(
                Modifier.size(36.dp).clip(RoundedCornerShape(11.dp)).background(Color.White.copy(alpha = 0.16f)),
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Filled.School, null, tint = Color.White, modifier = Modifier.size(20.dp)) }
            Spacer(Modifier.height(16.dp))
            Text(title, color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.height(4.dp))
            Text(subtitle, color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp)
        }
        Box(
            Modifier.align(Alignment.BottomStart).padding(start = 24.dp).offset(y = 3.dp)
                .size(54.dp, 6.dp).clip(RoundedCornerShape(3.dp)).background(Yellow)
        )
    }
}

@Composable
fun AppField(
    value: String,
    onChange: (String) -> Unit,
    placeholder: String,
    icon: ImageVector? = null,
    keyboard: KeyboardType = KeyboardType.Text,
    password: Boolean = false,
    singleLine: Boolean = true
) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        placeholder = { Text(placeholder) },
        leadingIcon = if (icon != null) { { Icon(icon, null) } } else null,
        singleLine = singleLine,
        minLines = if (singleLine) 1 else 3,
        shape = RoundedCornerShape(14.dp),
        visualTransformation = if (password) PasswordVisualTransformation() else VisualTransformation.None,
        keyboardOptions = KeyboardOptions(keyboardType = keyboard),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Blue,
            unfocusedBorderColor = FieldBorder,
            focusedContainerColor = Color.White,
            unfocusedContainerColor = FieldBg,
            focusedLeadingIconColor = Blue,
            unfocusedLeadingIconColor = Muted,
            cursorColor = Blue
        ),
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
fun PrimaryButton(text: String, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().height(50.dp),
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Blue, contentColor = Color.White)
    ) { Text(text, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp) }
}

/** "Already have an account?  Sign in" with a yellow underline on the action. */
@Composable
fun SwitchLink(question: String, action: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(top = 10.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.Top
    ) {
        Text(question, color = Muted, fontSize = 13.sp)
        Spacer(Modifier.width(6.dp))
        Column(Modifier.width(IntrinsicSize.Max).clickable(onClick = onClick)) {
            Text(action, color = Blue, fontWeight = FontWeight.ExtraBold, fontSize = 13.sp)
            Box(Modifier.fillMaxWidth().height(3.dp).background(Yellow))
        }
    }
}
