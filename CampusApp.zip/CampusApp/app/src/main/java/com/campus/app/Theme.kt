package com.campus.app

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Blue = Color(0xFF1E4FD8)
val BlueDark = Color(0xFF10224F)
val Yellow = Color(0xFFFFC93C)
val FieldBg = Color(0xFFF3F6FD)
val FieldBorder = Color(0xFFE1E8F7)
val Muted = Color(0xFF6B7A99)
val SoftBlue = Color(0xFFE8EFFD)
val ErrorRed = Color(0xFFC62828)

private val Scheme = lightColorScheme(
    primary = Blue,
    onPrimary = Color.White,
    secondary = Yellow,
    onSecondary = BlueDark,
    background = Color.White,
    onBackground = BlueDark,
    surface = Color.White,
    onSurface = BlueDark
)

@Composable
fun CampusTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, content = content)
}
