package com.campus.app

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

@Composable
fun SplashScreen(onFinish: () -> Unit) {
    LaunchedEffect(Unit) {
        delay(3000)
        onFinish()
    }
    Column(
        Modifier.fillMaxSize().background(Color.White),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        AppLogo()
        Spacer(Modifier.height(20.dp))
        Text("Campus", color = Blue, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.height(4.dp))
        Text("Your university, in your pocket", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(64.dp))
        CircularProgressIndicator(
            color = Blue,
            trackColor = Color(0xFFDCE6FB),
            strokeWidth = 4.dp,
            modifier = Modifier.size(38.dp)
        )
    }
}

@Composable
fun SignUpScreen(store: Store, onSignIn: () -> Unit, onDone: () -> Unit) {
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    Column(Modifier.fillMaxSize().background(Color.White).verticalScroll(rememberScrollState())) {
        ScreenHeader("Create account", "Join your campus community")
        Column(
            Modifier.padding(start = 22.dp, end = 22.dp, top = 26.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(13.dp)
        ) {
            AppField(name, { name = it }, "Full name", Icons.Filled.Person)
            AppField(email, { email = it }, "University email", Icons.Filled.Email, KeyboardType.Email)
            AppField(pass, { pass = it }, "Password", Icons.Filled.Lock, KeyboardType.Password, password = true)
            error?.let { Text(it, color = ErrorRed, fontSize = 13.sp) }
            PrimaryButton("Sign up") {
                error = when {
                    name.isBlank() -> "Please enter your full name."
                    !isValidEmail(email) -> "Please enter a valid email."
                    pass.length < 6 -> "Password must be at least 6 characters."
                    else -> store.signUp(name, email, pass)
                }
                if (error == null) onDone()
            }
            SwitchLink("Already have an account?", "Sign in", onSignIn)
        }
    }
}

@Composable
fun SignInScreen(store: Store, onSignUp: () -> Unit, onDone: () -> Unit) {
    var email by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    Column(Modifier.fillMaxSize().background(Color.White).verticalScroll(rememberScrollState())) {
        ScreenHeader("Welcome back", "Sign in to continue")
        Column(
            Modifier.padding(start = 22.dp, end = 22.dp, top = 26.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(13.dp)
        ) {
            AppField(email, { email = it }, "University email", Icons.Filled.Email, KeyboardType.Email)
            AppField(pass, { pass = it }, "Password", Icons.Filled.Lock, KeyboardType.Password, password = true)
            Text(
                "Forgot password?", color = Blue, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.align(Alignment.End)
            )
            error?.let { Text(it, color = ErrorRed, fontSize = 13.sp) }
            PrimaryButton("Sign in") {
                error = when {
                    !isValidEmail(email) -> "Please enter a valid email."
                    pass.isEmpty() -> "Please enter your password."
                    else -> store.signIn(email, pass)
                }
                if (error == null) onDone()
            }
            SwitchLink("New here?", "Create account", onSignUp)
        }
    }
}
