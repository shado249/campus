package com.campus.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val store = Store(applicationContext)
        setContent { CampusTheme { AppNav(store) } }
    }
}

@Composable
fun AppNav(store: Store) {
    val nav = rememberNavController()
    NavHost(navController = nav, startDestination = "splash") {
        composable("splash") {
            SplashScreen {
                val next = if (store.currentUser() != null) "home" else "signup"
                nav.navigate(next) { popUpTo("splash") { inclusive = true } }
            }
        }
        composable("signup") {
            SignUpScreen(
                store,
                onSignIn = { nav.navigate("signin") },
                onDone = { nav.navigate("home") { popUpTo("signup") { inclusive = true } } }
            )
        }
        composable("signin") {
            SignInScreen(
                store,
                onSignUp = { nav.popBackStack() },
                onDone = { nav.navigate("home") { popUpTo("signup") { inclusive = true } } }
            )
        }
        composable("home") {
            HomeScreen(store, onSignOut = {
                nav.navigate("signup") { popUpTo("home") { inclusive = true } }
            })
        }
    }
}
