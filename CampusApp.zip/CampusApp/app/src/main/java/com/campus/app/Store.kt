package com.campus.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest

data class User(val name: String, val email: String)
data class Project(val title: String, val description: String, val url: String, val author: String)

/** Simple on-device storage (SharedPreferences). */
class Store(context: Context) {
    private val sp = context.getSharedPreferences("campus", Context.MODE_PRIVATE)

    private fun hash(s: String) = MessageDigest.getInstance("SHA-256")
        .digest(s.toByteArray()).joinToString("") { "%02x".format(it) }

    private fun users() = JSONArray(sp.getString("users", "[]"))

    fun signUp(name: String, email: String, password: String): String? {
        val e = email.trim().lowercase()
        val users = users()
        for (i in 0 until users.length()) {
            if (users.getJSONObject(i).getString("email") == e) {
                return "This email is already registered. Try signing in."
            }
        }
        users.put(JSONObject().put("name", name.trim()).put("email", e).put("password", hash(password)))
        sp.edit().putString("users", users.toString()).putString("session", e).apply()
        return null
    }

    fun signIn(email: String, password: String): String? {
        val e = email.trim().lowercase()
        val users = users()
        for (i in 0 until users.length()) {
            val u = users.getJSONObject(i)
            if (u.getString("email") == e) {
                return if (u.getString("password") == hash(password)) {
                    sp.edit().putString("session", e).apply()
                    null
                } else "Wrong password. Please try again."
            }
        }
        return "No account found with this email."
    }

    fun currentUser(): User? {
        val e = sp.getString("session", null) ?: return null
        val users = users()
        for (i in 0 until users.length()) {
            val u = users.getJSONObject(i)
            if (u.getString("email") == e) return User(u.getString("name"), e)
        }
        return null
    }

    fun signOut() { sp.edit().remove("session").apply() }

    fun projects(): List<Project> {
        val arr = JSONArray(sp.getString("projects", "[]"))
        return List(arr.length()) { i ->
            val o = arr.getJSONObject(i)
            Project(o.getString("title"), o.getString("description"), o.getString("url"), o.getString("author"))
        }
    }

    fun addProject(p: Project) {
        val old = JSONArray(sp.getString("projects", "[]"))
        val arr = JSONArray()
        arr.put(JSONObject().put("title", p.title).put("description", p.description)
            .put("url", p.url).put("author", p.author))
        for (i in 0 until old.length()) arr.put(old.get(i))
        sp.edit().putString("projects", arr.toString()).apply()
    }
}

fun isValidEmail(s: String) = android.util.Patterns.EMAIL_ADDRESS.matcher(s.trim()).matches()
