package com.campus.app

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val interviewData: List<Pair<String, List<Pair<String, String>>>> = listOf(
    "HR" to listOf(
        "Tell me about yourself." to "Keep it to one minute: who you are, what you study, one project, and why you are applying.",
        "Why do you want to join this company or program?" to "Mention two specific things you researched (their products or curriculum) and link them to your goals.",
        "What are your strengths and weaknesses?" to "Pick a real strength with an example, and a weakness you are actively improving.",
        "Tell me about a time you worked in a team." to "Use STAR: Situation, Task, Action, Result. Focus on your own contribution.",
        "Where do you see yourself in 5 years?" to "Show growth: deeper technical skills, more responsibility, and continuous learning."
    ),
    "Programming" to listOf(
        "What are the four pillars of OOP?" to "Encapsulation, inheritance, polymorphism, abstraction. Prepare one tiny example for each.",
        "Array vs linked list?" to "Array: contiguous memory, O(1) access by index, costly inserts. Linked list: nodes with pointers, O(1) insert at head, O(n) access.",
        "Stack vs queue?" to "Stack is LIFO (undo, call stack). Queue is FIFO (printer, BFS).",
        "What is Big-O notation?" to "It describes how time or memory grows with input size, e.g. binary search O(log n), linear scan O(n).",
        "What is a REST API?" to "A style for client-server communication over HTTP using resources and verbs (GET, POST, PUT, DELETE), usually with JSON.",
        "Explain recursion." to "A function calling itself with a base case and a smaller subproblem, e.g. factorial."
    ),
    "Databases" to listOf(
        "Primary key vs foreign key?" to "A primary key uniquely identifies a row. A foreign key references the primary key of another table.",
        "What are the types of SQL JOIN?" to "INNER, LEFT, RIGHT and FULL. Explain which rows each one keeps.",
        "What is normalization?" to "Organizing tables to reduce redundancy and anomalies (1NF, 2NF, 3NF).",
        "SQL vs NoSQL?" to "SQL: fixed schema, relations, ACID. NoSQL: flexible schema, easy to scale out (document, key-value)."
    ),
    "Training" to listOf(
        "Can you commit to the full program schedule?" to "Be honest about your timetable and show discipline and a plan to manage studies.",
        "Tell me about a project you built." to "Problem, your role, technologies, one challenge, result. Have your GitHub link ready.",
        "How do you learn a new technology?" to "Official docs, a small project, courses or YouTube, then ask for feedback.",
        "Why should we choose you?" to "Connect skills, attitude and examples. Be confident, concise and not arrogant.",
        "Do you have any questions for us?" to "Always ask: team structure, learning path, and what success looks like in the first 3 months."
    )
)

@Composable
fun InterviewPage() {
    var cat by rememberSaveable { mutableIntStateOf(0) }
    var openIndex by rememberSaveable { mutableIntStateOf(-1) }

    Column(Modifier.fillMaxSize().background(Color.White)) {
        ScreenHeader("Interview Prep", "Expected questions for jobs and trainings")
        Row(
            Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 14.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            interviewData.forEachIndexed { i, (name, _) ->
                val selected = i == cat
                Text(
                    name,
                    color = if (selected) Color.White else BlueDark,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .border(1.5.dp, if (selected) Blue else FieldBorder, RoundedCornerShape(20.dp))
                        .background(if (selected) Blue else FieldBg)
                        .clickable { cat = i; openIndex = -1 }
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                )
            }
        }
        LazyColumn(
            contentPadding = PaddingValues(start = 18.dp, end = 18.dp, bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            itemsIndexed(interviewData[cat].second) { index, (question, answer) ->
                Column(
                    Modifier.fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .border(1.dp, FieldBorder, RoundedCornerShape(16.dp))
                        .background(FieldBg)
                        .clickable { openIndex = if (openIndex == index) -1 else index }
                        .padding(14.dp)
                ) {
                    Row(verticalAlignment = Alignment.Top) {
                        Box(
                            Modifier.size(24.dp).clip(RoundedCornerShape(8.dp)).background(Yellow),
                            contentAlignment = Alignment.Center
                        ) { Text("${index + 1}", fontWeight = FontWeight.ExtraBold, fontSize = 12.sp, color = BlueDark) }
                        Spacer(Modifier.width(10.dp))
                        Text(question, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp, color = BlueDark)
                    }
                    if (openIndex == index) {
                        Spacer(Modifier.height(10.dp))
                        Text(answer, fontSize = 13.sp, lineHeight = 19.sp, color = Muted, modifier = Modifier.padding(start = 34.dp))
                    }
                }
            }
        }
    }
}
