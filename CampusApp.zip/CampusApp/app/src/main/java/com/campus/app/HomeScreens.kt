package com.campus.app

import android.content.Intent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// ---------- Data (real links) ----------

data class LinkItem(val title: String, val desc: String, val url: String)

private val trainings = listOf(
    LinkItem("Digital Egypt Pioneers Initiative (DEPI)",
        "Free national scholarship by MCIT: software, AI, data, cybersecurity and more.",
        "https://www.depi.gov.eg"),
    LinkItem("Digital Pioneers (Digilians)",
        "Presidential initiative with the Egyptian Military Academy: diplomas and professional master's tracks.",
        "https://www.digilians.gov.eg"),
    LinkItem("ITI - Information Technology Institute",
        "Intensive professional training programs and summer tracks for students and graduates.",
        "https://iti.gov.eg"),
    LinkItem("NTI - National Telecommunication Institute",
        "Training courses in telecom, networks and IT from the Ministry of Communications.",
        "https://www.nti.sci.eg"),
    LinkItem("Ministry of Communications (MCIT)",
        "Official announcements for all digital training initiatives in Egypt.",
        "https://mcit.gov.eg")
)

private fun yt(name: String) = "https://www.youtube.com/results?search_query=" + name.replace(" ", "+")

private val channels = listOf(
    LinkItem("Elzero Web School", "Full Arabic courses: web development, programming languages and more.", yt("Elzero Web School")),
    LinkItem("Codezilla", "Coding tutorials and programming fundamentals in Arabic.", yt("Codezilla")),
    LinkItem("Abdelrahman Gamal", "Programming topics explained in short, focused videos.", yt("Abdelrahman Gamal")),
    LinkItem("Dr. Ahmed Hagag", "University-level CS, AI, math and software engineering made simple.", yt("Dr Ahmed Hagag")),
    LinkItem("Mohamed Taha", "CS course explanations by a lecturer from Benha FCAI.", yt("Mohamed Taha Benha computer science")),
    LinkItem("Amr Ghoneim", "Computer science and AI from an academic researcher.", yt("Amr Ghoneim")),
    LinkItem("Adel Nasim", "Programming languages and problem solving in Arabic.", yt("Adel Nasim")),
    LinkItem("Omar Ahmed", "Java, OOP, clean code and Flutter.", yt("Omar Ahmed Java Flutter"))
)

// ---------- Home with bottom navigation ----------

@Composable
fun HomeScreen(store: Store, onSignOut: () -> Unit) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val tabs = listOf(
        Triple("Training", Icons.Filled.Work, 0),
        Triple("Studying", Icons.Filled.PlayCircle, 1),
        Triple("Projects", Icons.Filled.Code, 2),
        Triple("Interview", Icons.Filled.Chat, 3),
        Triple("Profile", Icons.Filled.Person, 4)
    )
    Scaffold(
        containerColor = Color.White,
        bottomBar = {
            NavigationBar(containerColor = Color.White) {
                tabs.forEach { (label, icon, index) ->
                    NavigationBarItem(
                        selected = tab == index,
                        onClick = { tab = index },
                        icon = { Icon(icon, label) },
                        label = { Text(label, fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.White,
                            indicatorColor = Blue,
                            selectedTextColor = Blue,
                            unselectedIconColor = Muted,
                            unselectedTextColor = Muted
                        )
                    )
                }
            }
        }
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            when (tab) {
                0 -> LinksPage("Approved Training", "Official summer training programs", trainings, Icons.Filled.Work)
                1 -> LinksPage("Your Studying", "Egyptian YouTube channels for CS students", channels, Icons.Filled.PlayCircle)
                2 -> ProjectsPage(store)
                3 -> InterviewPage()
                else -> ProfilePage(store, onSignOut)
            }
        }
    }
}

@Composable
private fun openLink(): (String) -> Unit {
    val handler = LocalUriHandler.current
    return { url -> try { handler.openUri(url) } catch (_: Exception) { } }
}

// ---------- Training / Studying ----------

@Composable
fun LinksPage(title: String, subtitle: String, entries: List<LinkItem>, icon: ImageVector) {
    val open = openLink()
    Column(Modifier.fillMaxSize().background(Color.White)) {
        ScreenHeader(title, subtitle)
        LazyColumn(
            contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 22.dp, bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(entries) { item ->
                Row(
                    Modifier.fillMaxWidth()
                        .clip(RoundedCornerShape(18.dp))
                        .border(1.dp, FieldBorder, RoundedCornerShape(18.dp))
                        .background(FieldBg)
                        .clickable { open(item.url) }
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        Modifier.size(44.dp).clip(RoundedCornerShape(13.dp)).background(Blue),
                        contentAlignment = Alignment.Center
                    ) { Icon(icon, null, tint = Color.White) }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(item.title, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp, color = BlueDark)
                        Spacer(Modifier.height(3.dp))
                        Text(item.desc, fontSize = 12.sp, color = Muted, lineHeight = 17.sp)
                    }
                    Spacer(Modifier.width(8.dp))
                    Icon(Icons.Filled.OpenInNew, "Open", tint = Blue, modifier = Modifier.size(20.dp))
                }
            }
        }
    }
}

// ---------- Projects ----------

@Composable
fun ProjectsPage(store: Store) {
    val open = openLink()
    var projects by remember { mutableStateOf(store.projects()) }
    var showAdd by remember { mutableStateOf(false) }

    Box(Modifier.fillMaxSize().background(Color.White)) {
        Column(Modifier.fillMaxSize()) {
            ScreenHeader("Projects", "Share your GitHub work and learn from classmates")
            if (projects.isEmpty()) {
                Column(
                    Modifier.fillMaxSize().padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(Icons.Filled.Code, null, tint = Blue, modifier = Modifier.size(44.dp))
                    Spacer(Modifier.height(10.dp))
                    Text("No projects yet", fontWeight = FontWeight.ExtraBold, fontSize = 17.sp)
                    Text("Tap Add project to share the first one.", color = Muted, fontSize = 13.sp)
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 22.dp, bottom = 90.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(projects) { p ->
                        Column(
                            Modifier.fillMaxWidth()
                                .clip(RoundedCornerShape(18.dp))
                                .border(1.dp, FieldBorder, RoundedCornerShape(18.dp))
                                .background(FieldBg)
                                .padding(16.dp)
                        ) {
                            Text(p.title, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, color = BlueDark)
                            Text("by ${p.author}", fontSize = 12.sp, color = Muted)
                            Spacer(Modifier.height(8.dp))
                            Text(p.description, fontSize = 13.sp, lineHeight = 19.sp)
                            Spacer(Modifier.height(12.dp))
                            Button(
                                onClick = { open(p.url) },
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Blue)
                            ) {
                                Icon(Icons.Filled.OpenInNew, null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("Open on GitHub", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
        ExtendedFloatingActionButton(
            onClick = { showAdd = true },
            icon = { Icon(Icons.Filled.Add, null) },
            text = { Text("Add project", fontWeight = FontWeight.ExtraBold) },
            containerColor = Yellow,
            contentColor = BlueDark,
            modifier = Modifier.align(Alignment.BottomEnd).padding(18.dp)
        )
    }

    if (showAdd) {
        var title by remember { mutableStateOf("") }
        var url by remember { mutableStateOf("") }
        var desc by remember { mutableStateOf("") }
        var error by remember { mutableStateOf<String?>(null) }
        AlertDialog(
            onDismissRequest = { showAdd = false },
            containerColor = Color.White,
            title = { Text("Add your project", fontWeight = FontWeight.ExtraBold) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    AppField(title, { title = it }, "Project name")
                    AppField(url, { url = it }, "GitHub link", keyboard = KeyboardType.Uri)
                    AppField(desc, { desc = it }, "Short description", singleLine = false)
                    error?.let { Text(it, color = ErrorRed, fontSize = 13.sp) }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val link = url.trim()
                    when {
                        title.isBlank() -> error = "Please name your project."
                        !link.startsWith("https://github.com/") -> error = "Link must start with https://github.com/"
                        desc.isBlank() -> error = "Please add a short description."
                        else -> {
                            val author = store.currentUser()?.name ?: "Student"
                            store.addProject(Project(title.trim(), desc.trim(), link, author))
                            projects = store.projects()
                            showAdd = false
                        }
                    }
                }) { Text("Add project", color = Blue, fontWeight = FontWeight.Bold) }
            },
            dismissButton = { TextButton(onClick = { showAdd = false }) { Text("Cancel", color = Muted) } }
        )
    }
}

// ---------- Profile ----------

@Composable
fun ProfilePage(store: Store, onSignOut: () -> Unit) {
    val context = LocalContext.current
    val user = store.currentUser()
    var showSettings by remember { mutableStateOf(false) }
    var notifications by remember { mutableStateOf(true) }

    Column(Modifier.fillMaxSize().background(Color.White).verticalScroll(rememberScrollState())) {
        ScreenHeader("Profile", "Your account")
        Column(
            Modifier.fillMaxWidth().padding(top = 26.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                Modifier.size(84.dp).clip(CircleShape).background(Blue).border(4.dp, Yellow, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    (user?.name?.firstOrNull() ?: 'S').uppercase(),
                    color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.ExtraBold
                )
            }
            Spacer(Modifier.height(12.dp))
            Text(user?.name ?: "Student", fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
            Text(user?.email ?: "", fontSize = 13.sp, color = Muted)
        }
        Column(Modifier.padding(18.dp).padding(top = 14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            ProfileRow(Icons.Filled.Settings, "Settings") { showSettings = true }
            ProfileRow(Icons.Filled.Share, "Share app") {
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, "Try Campus - the study companion for university students!")
                }
                context.startActivity(Intent.createChooser(send, "Share Campus"))
            }
            ProfileRow(Icons.AutoMirrored.Filled.Logout, "Sign out") {
                store.signOut()
                onSignOut()
            }
        }
    }

    if (showSettings) {
        AlertDialog(
            onDismissRequest = { showSettings = false },
            containerColor = Color.White,
            title = { Text("Settings", fontWeight = FontWeight.ExtraBold) },
            text = {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Notifications", Modifier.weight(1f))
                        Switch(
                            checked = notifications,
                            onCheckedChange = { notifications = it },
                            colors = SwitchDefaults.colors(checkedTrackColor = Blue, checkedThumbColor = Color.White)
                        )
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("Version 1.0", color = Muted, fontSize = 12.sp)
                }
            },
            confirmButton = { TextButton(onClick = { showSettings = false }) { Text("Done", color = Blue, fontWeight = FontWeight.Bold) } }
        )
    }
}

@Composable
private fun ProfileRow(icon: ImageVector, label: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .border(1.dp, FieldBorder, RoundedCornerShape(16.dp))
            .background(FieldBg)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(38.dp).clip(RoundedCornerShape(11.dp)).background(SoftBlue),
            contentAlignment = Alignment.Center
        ) { Icon(icon, null, tint = Blue) }
        Spacer(Modifier.width(14.dp))
        Text(label, Modifier.weight(1f), fontWeight = FontWeight.Bold, fontSize = 15.sp)
        Icon(Icons.Filled.ChevronRight, null, tint = Muted)
    }
}
